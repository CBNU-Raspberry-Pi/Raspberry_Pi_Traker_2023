import cv2
import tkinter as tk

# 변수 초기화
text_value = "0"

# 웹캠 시작
cap = cv2.VideoCapture(0)

# 숫자 변경 함수
def change_text():
    global text_value
    text_value = entry.get()

# UI 구성
root = tk.Tk()
entry = tk.Entry(root)
entry.pack()
button = tk.Button(root, text="텍스트 변경", command=change_text)
button.pack()

# 메인 루프 실행
while True:
    # 웹캠에서 프레임 읽기
    ret, frame = cap.read()

    # 프레임에 텍스트 추가
    cv2.putText(frame, text_value, (10, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

    # 프레임 화면에 표시
    cv2.imshow("Webcam", frame)

    # UI 이벤트 처리
    root.update()

    # 'q' 키를 누르면 종료
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# 자원 해제
cap.release()
cv2.destroyAllWindows()