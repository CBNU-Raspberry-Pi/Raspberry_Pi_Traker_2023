import cv2
import numpy as np
import contours as ct

img1 = cv2.imread('img.jpg')

h,w,c = img1.shape

img1 = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY) ## 새로받은 이미지 흑백처리
img1 = cv2.GaussianBlur(src=img1, ksize=(5, 5), sigmaX=0)

img2 = cv2.imread('img1.jpg')



print(h,w)

total_sketch = np.zeros((h,w,3),dtype=np.uint8)

contours = ct.find_contours(img1,img2) 

for contour in contours:

    cv2.drawContours(image=total_sketch, contours=contours, contourIdx=-1, color=(0, 255, 0), thickness=2, lineType=cv2.LINE_AA)

    # 사각형과 점 표시
    if cv2.contourArea(contour) < 50:
        continue
    (x, y, w, h) = cv2.boundingRect(contour)



    # print(ini_loc,"hmm")

    cv2.circle(img=total_sketch, center=(int((2*x+w)/2),int((2*y+h)/2)),radius=10, color=(0, 0, 255), thickness=2)
    cv2.rectangle(img=total_sketch, pt1=(x, y), pt2=(x + w, y + h), color=(255, 0, 0), thickness=2)
    ini_loc = [int((2*x+w)/2),int((2*y+h)/2)]

    img1 = cv2.cvtColor('img.jpg1',cv2.COLOR_BGR2GRAY) ## 새로받은 이미지 흑백처리

    cv2.imshow('Motion detect', img1)
    cv2.imshow('Motion detecr', img2)
    cv2.imshow('Motion detector', total_sketch)
    cv2.waitKey(0)









