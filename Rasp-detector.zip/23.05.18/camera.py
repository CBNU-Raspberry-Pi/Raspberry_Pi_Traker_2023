import cv2
import numpy as np
from PIL import ImageGrab

cap = cv2.VideoCapture(0)

ret,frame = cap.read()


  

