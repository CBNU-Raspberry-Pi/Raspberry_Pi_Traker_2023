import cv2
import numpy as np
from PIL import ImageGrab

def array_mean(array):

  # print(array[0],"shit")
  # print(array[:][0],"shit 2")
  # print(array[0][0][0],"shit 3")
  # print(array[0][0][0][0],array[0][0][0][1],"shit 4")
  number = len(array[0])
  # print(number)
  mean_x = 0
  mean_y = 0 

  for i in range(number):
    mean_x += array[0][0][i][0]
    print(mean_x)
    mean_y += array[0][0][i][1]

  array = (int(mean_x/number),int(mean_y/number))
  print(array)
  return array

def motion_detector_gist():
#   cap = cv2.VideoCapture('output.mp4')
  
  cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
  previous_frame = None

  while(cap.isOpened()):

    # 1. Load image; convert to RGB
    # img_brg = np.array(cap)
    # img_rgb = cv2.cvtColor(src=img_brg, code=cv2.COLOR_BGR2RGB)
    ret, frame = cap.read()
    img_rgb = frame


    # 2. Prepare image; grayscale and blur
    prepared_frame = cv2.cvtColor(img_rgb, cv2.COLOR_BGR2GRAY)
    prepared_frame = cv2.GaussianBlur(src=prepared_frame, ksize=(5, 5), sigmaX=0)

    # 2. Calculate the difference
    if (previous_frame is None):
      # First frame; there is no previous one yet
      previous_frame = prepared_frame
      continue

    # 3. calculate difference and update previous frame
    diff_frame = cv2.absdiff(src1=previous_frame, src2=prepared_frame)
    previous_frame = prepared_frame

    # 4. Dilute the image a bit to make differences more seeable; more suitable for contour detection
    kernel = np.ones((5, 5))
    diff_frame = cv2.dilate(diff_frame, kernel, 1)

    # 5. Only take different areas that are different enough (>20 / 255)
    thresh_frame = cv2.threshold(src=diff_frame, thresh=20, maxval=255, type=cv2.THRESH_BINARY)[1]

    # 6. Find and optionally draw contours
    contours = cv2.findContours(image=thresh_frame, mode=cv2.RETR_EXTERNAL, method=cv2.CHAIN_APPROX_SIMPLE)
    
    if contours != ():
      print(contours[0], "1")             ## 윤곽선좌표들의 모음 [ [ [] [] []...] [ [] [] [] ...] ...]
      print(contours[0][0], "2")          ## 윤곽선 좌표 [[] [] [] [] [] ...]
      print(contours[0][0][0], "3")       ## 좌표 하나 [x y]
      print(contours[0][0][0][0], "4")    ## 좌표 하나 [x y ]
      print(contours[0][0][0][0][0], "5") ## x y값 
      
    else:
      print(1)


    # hoho = array_mean(contours)

    # cv2.circle(img=img_rgb, center=hoho,radius=10, color=(0, 255, 0), thickness=2)

    cv2.imshow('Motion detector', img_rgb)

    if (cv2.waitKey(30) == 27):
      # out.release()
      break

  # Cleanup
  cv2.destroyAllWindows()

if __name__ == "__main__":
  motion_detector_gist()