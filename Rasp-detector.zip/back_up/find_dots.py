import cv2
import numpy as np

height = 50
width = 50 

camera_sketch = np.zeros((height,width,3),dtype=np.uint8)

center = [375,375]


nof = 5


range = np.arange(-nof,nof+1,1)

print(range)

# for i in range(nof):
#     for j in range(nof):







