import cv2 


#동영상 불러오기
cap = cv2.VideoCapture('output.mp4')


#동영상 출력 - 실행시 큰 창으로 출력 
while(cap.isOpened()):
    ret, frame = cap.read() #동영상 정보 읽어오기 -read
    if ret:
    #frame은 이미지 정보이므로 imshow 로 읽어들일 수 있음
        cv2.imshow('frame', frame)  
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break
        
cap.release()
cv2.destroyAllWindows()