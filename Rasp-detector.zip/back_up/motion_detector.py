## source  https://gist.github.com/mike-huls/372d968aa523484b8cca05844dfc8443


import cv2
import numpy as np

def array_mean(array):

  # print(array[0],"shit")
  # print(array[:][0],"shit 2")
  # print(array[0][0][0],"shit 3")
  # print(array[0][0][0][0],array[0][0][0][1],"shit 4")
  number = len(array[0])
  # print(number)
  mean_x = 0
  mean_y = 0 

  for i in range(number):
    mean_x += array[0][i][0][0]
    mean_y += array[0][i][0][1]

  array = (int(mean_x/number),int(mean_y/number))
  print(array)
  return array

def motion_detector_gist():
  cap = cv2.VideoCapture('output.mp4')
  # cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
  previous_frame = None


  cont_list = [] 
  while (cap.isOpened()):
    
    # 1. Load image; convert to RGB
    # img_brg = np.array(ImageGrab.grab())

    ret, frame = cap.read()
    # img_rgb = cv2.cvtColor(src=frame, code=cv2.COLOR_BGR2RGB)
    img_rgb = frame
    # img_rgb = cv2.flip(img_rgb,)

    # 2. Prepare image; grayscale and blur
    prepared_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    prepared_frame = cv2.GaussianBlur(src=prepared_frame, ksize=(7, 7), sigmaX=0)
    cv2.imshow("gaussian",prepared_frame) ## 가우시안 처리된 프레임 

    # 2. Calculate the difference
    if (previous_frame is None):
      # First frame; there is no previous one yet
      previous_frame = prepared_frame
      continue

    # 3. calculate difference and update previous frame
    diff_frame = cv2.absdiff(src1=previous_frame, src2=prepared_frame) ## 흑백처리한 두 프레임사이의 차이값을 반환 
    cv2.imshow('frame diff',diff_frame) 

    previous_frame = prepared_frame

    # 4. Dilute the image a bit to make differences more seeable; more suitable for contour detection
    kernel = np.ones((5, 5)) ## 커널값( https://diyver.tistory.com/61 예시에서 커널값 처리 범위 정하기) 
    diff_frame = cv2.dilate(diff_frame, kernel, 1) ## dilate과정(위에서 정한 커널값에서 가장 최솟값으로 커널을 통일화시킴, 이를 1번 반복)   
    cv2.imshow("dilate example",diff_frame) ## 

    # 5. Only take different areas that are different enough (>20 / 255)

    ## 이미지 불러오기 
    thresh_frame = cv2.threshold(src=diff_frame, thresh=20, maxval=255, type=cv2.THRESH_BINARY)[1] ## 이미지 이진화 처리(임계값 20보다 차이날 경우 1로 반환)
    cv2.imshow("thresh example",thresh_frame) 

    # 6. Find and optionally draw contours
    contours, _ = cv2.findContours(image=thresh_frame, mode=cv2.RETR_EXTERNAL, method=cv2.CHAIN_APPROX_SIMPLE)

    cont_list.append(contours) ## 윤곽선 데이터를 저장
    
    # print(contours,"shit") ## 윤곽선 데이터를 print

    # hoho = array_mean(contours) ## 윤곽선 데이터의 x y평균값을 구하는 함수 


    
    # Comment below to stop drawing contours
    # cv2.drawContours(image=img_rgb, contours=contours, contourIdx=-1, color=(0, 255, 0), thickness=2, lineType=cv2.LINE_AA) ## 윤곽선 그리기 
    # Uncomment 6 lines below to stop drawing rectangles
    # for contour in contours:
    #   if cv2.contourArea(contour) < 50:
    #     # too small: skip!
    #       continue
    #   (x, y, w, h) = cv2.boundingRect(contour)
    # cv2.circle(img=img_rgb, center=hoho,radius=10, color=(0, 255, 0), thickness=2)

    cv2.imshow('Motion detector', img_rgb)

    if (cv2.waitKey(50) == 'q'):
    #   out.release()
      break

  # Cleanup
  cap.release()
  cv2.destroyAllWindows()
  return cont_list

if __name__ == "__main__":
  motion_detector_gist()
  


